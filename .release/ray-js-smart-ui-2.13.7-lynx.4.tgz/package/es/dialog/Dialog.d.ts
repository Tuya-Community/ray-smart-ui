/// <reference types="react" />
import DialogInstance from '@tuya/miniapp-smart-ui/dist/dialog/dialog';
import { SmartDialogProps } from './PropTypes';
declare const _default: import("react").FC<SmartDialogProps>;
export default _default;
export { DialogInstance };
