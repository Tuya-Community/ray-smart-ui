export default function BottomSheet({ children, show, ...rest }: {
    [x: string]: any;
    children: any;
    show: any;
}): import("react/jsx-runtime").JSX.Element;
