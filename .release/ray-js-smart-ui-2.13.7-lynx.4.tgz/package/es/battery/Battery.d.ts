declare const _default: (props: Record<string, any>) => import("react/jsx-runtime").JSX.Element;
export default _default;
