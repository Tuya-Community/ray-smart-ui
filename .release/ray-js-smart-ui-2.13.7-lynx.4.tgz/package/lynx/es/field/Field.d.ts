import Field from '@tuya/miniapp-smart-ui/lynx/dist/field/index';
export { getNumberFormatConfig, parseFormattedNumber, formatNumber, } from '@tuya/miniapp-smart-ui/lynx/dist/field/numberFormat';
export default Field;
