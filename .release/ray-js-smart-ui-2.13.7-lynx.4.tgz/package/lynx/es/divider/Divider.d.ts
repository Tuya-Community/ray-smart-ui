import Divider from '@tuya/miniapp-smart-ui/lynx/dist/divider/index';
export default Divider;
