import CellGroup from '@tuya/miniapp-smart-ui/lynx/dist/cell-group/index';
export default CellGroup;
