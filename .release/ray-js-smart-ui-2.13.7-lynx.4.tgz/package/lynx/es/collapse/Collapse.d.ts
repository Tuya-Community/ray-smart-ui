import Collapse from '@tuya/miniapp-smart-ui/lynx/dist/collapse/index';
export default Collapse;
