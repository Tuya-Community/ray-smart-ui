import Image from '@tuya/miniapp-smart-ui/lynx/dist/image/index';
export default Image;
