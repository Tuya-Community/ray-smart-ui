import CollapseItem from '@tuya/miniapp-smart-ui/lynx/dist/collapse-item/index';
export default CollapseItem;
