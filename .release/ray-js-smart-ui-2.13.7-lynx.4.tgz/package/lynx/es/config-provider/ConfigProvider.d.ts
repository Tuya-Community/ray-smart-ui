import ConfigProvider from '@tuya/miniapp-smart-ui/lynx/dist/config-provider/index';
export default ConfigProvider;
